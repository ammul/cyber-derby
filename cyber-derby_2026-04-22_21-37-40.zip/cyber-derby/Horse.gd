extends Node2D

@export var is_npc: bool = true # Häkchen im Inspektor für Gegner-Pferde
var decision_timer: float = 0.0

@export var repulsion_radius: float = 40.0 # Wie nah dürfen sie ran?
@export var repulsion_strength: float = 100.0 # Wie stark drücken sie sich weg?

@export var horse_index: int = 0
@onready var lane_index: int = horse_index
@export var body_color = Color(0.6, 0.4, 0.2) # Braun
@export var head_color = Color(0.5, 0.3, 0.1) # Dunkleres Braun
@export var base_speed: float = 110.0

@onready var track = $".."

var has_finished: bool = false
var speed_modifier: float = 1.0
var animation_time: float = 0.0

# --- Dynamik-Variablen ---
var noise_offset: float = randf() * 100.0 # Einzigartiger Wert für Zufalls-Kurve
var slipstream_bonus: float = 0.0          # Aktueller Windschatten-Boost
var catch_up_mult: float = 0.5            # Rubber-Banding Faktor
var target_mod_vis: float = 1.0           # Für sanften Farbwechsel

var lightning_timer: float = 0.0
var is_shocked: bool = false

func _ready():
	add_to_group("horses")
	# 1. Alle Pferde exakt auf die Startlinie setzen
	if track:
		position.x = track.start_line_x - 30
		# Y-Position basierend auf der Lane setzen
		position.y = lane_index * track.cell_size + (track.cell_size / 2.0)

func get_struck_by_lightning():
	is_shocked = true
	lightning_timer = 2.0 # Der Effekt hält 2 Sekunden an
	
	# Der "doppelte Effekt": Wenn Slow normal 0.5 ist, nehmen wir hier 0.1 für extra harten Schock
	speed_modifier = 0.1 
	
	# Visuelles Feedback: Das Pferd kurz weiß aufblitzen lassen
	modulate = Color(10, 10, 10) 
	await get_tree().create_timer(0.1).timeout
	modulate = Color(1, 1, 1) 

func _process(delta):
	if not track or track.is_race_over: return
	
	if not track.race_started:
		# Nervöses Wippen an der Startlinie
		animation_time += delta * 5.0 
		_apply_visual_smoothing()
		queue_redraw()
		return 

	# 1. Kacheln abfragen
	_check_tiles()

	# 2. Geschwindigkeit berechnen
	var flavor_speed = sin(Time.get_ticks_msec() * 0.001 + noise_offset) * 15.0
	_calculate_dynamics()
	var total_speed = (base_speed + flavor_speed) * speed_modifier * catch_up_mult + slipstream_bonus
	total_speed = max(10.0, total_speed)
	
	# Vorwärtsbewegung
	position.x += total_speed * delta

	# Die Animation läuft jetzt genau so schnell, wie das Pferd rennt!
	animation_time += delta * (total_speed * 0.05)

	# Glättung und KI
	_apply_visual_smoothing()
	_handle_npc_tactics(delta)
	
	# Blitz-Timer
	if is_shocked:
		lightning_timer -= delta
		if lightning_timer <= 0:
			is_shocked = false
			speed_modifier = 1.0 

	# Sieg-Check
	if position.x >= track.finish_line_column * track.cell_size and not has_finished:
		has_finished = true
		_celebrate_win()
		
	# Kollisions-Berechnung
	_handle_repulsion(delta)
	queue_redraw()

# --- Dynamik-Berechnungen ---

func _calculate_dynamics():
	var horses = get_tree().get_nodes_in_group("horses")
	if horses.is_empty(): return
	
	# 1. Rubber-Banding (Feld zusammenhalten)
	var lead_x = 0.0
	for h in horses: lead_x = max(lead_x, h.position.x)
	var dist_to_lead = lead_x - position.x
	catch_up_mult = 1.0 + clamp(dist_to_lead / 1500.0, 0.0, 0.3) 

	# 2. Windschatten berechnen
	slipstream_bonus = 0.0
	target_mod_vis = 1.0 
	
	for other in horses:
		if other == self: continue
		
		var x_dist = other.position.x - self.position.x
		
		# WICHTIGE ÄNDERUNG: Windschatten greift nur, wenn Vordermann mindestens 20 Pixel weit weg ist.
		# Verhindert, dass sie nebeneinander hängen bleiben.
		if other.lane_index == self.lane_index and x_dist > 20.0 and x_dist < 150.0:
			slipstream_bonus = (150.0 - x_dist) * 0.7 
			target_mod_vis = 1.5 
			break 

func _handle_npc_tactics(delta):
	if not is_npc or speed_modifier < 0.9: return 
	
	decision_timer -= delta
	if decision_timer > 0: return # Nur in Intervallen denken
	
	decision_timer = randf_range(0.2, 0.5) 
	
	var cell_x = int(position.x / track.cell_size)
	var look_ahead = 4 
	
	# 1. Overtaking / Kollisionsvermeidung
	for other in get_tree().get_nodes_in_group("horses"):
		if other == self: continue
		var x_dist = other.position.x - self.position.x
		# Wenn jemand direkt vor mir ist (innerhalb 50 Pixel)
		if other.lane_index == self.lane_index and x_dist > 0 and x_dist < 50:
			# Nur wechseln, wenn ich eigentlich schneller wäre
			if slipstream_bonus > 10.0 or speed_modifier > other.speed_modifier:
				_try_switch_lane() 
				return 
			
	# 2. Bahnen bewerten
	var best_lane = lane_index
	var best_score = -9999.0
	
	var lanes_to_check = [lane_index]
	if lane_index > 0: lanes_to_check.append(lane_index - 1)
	if lane_index < track.grid_height - 1: lanes_to_check.append(lane_index + 1)
	
	for l in lanes_to_check:
		var score = 0.0
		# Grund-Präferenz, in der aktuellen Spur zu bleiben (verhindert Zappeln)
		if l == lane_index: score += 1.0 
		
		# Echte Kacheln voraus bewerten
		for i in range(1, look_ahead + 1):
			var check_x = cell_x + i
			if check_x < track.grid_width:
				var tile = track.grid[check_x][l]
				var weight = float(look_ahead - i + 1) 
				if tile == track.Tile.BOOST: score += 5.0 * weight
				elif tile == track.Tile.SLOW: score -= 8.0 * weight 
					
		# Vorschau-Kacheln bewerten
		if track.is_aiming and track.aim_lane == l:
			var cam = get_viewport().get_camera_2d()
			if cam:
				var preview_x = int((cam.get_screen_center_position().x + (get_viewport_rect().size.x / 2.0) - track.placement_offset) / track.cell_size)
				if preview_x > cell_x and preview_x <= cell_x + look_ahead + 2:
					if track.aim_type == track.Tile.BOOST: score += 3.0
					elif track.aim_type == track.Tile.SLOW: score -= 4.0

		# NEU: Verkehrsstrafen (Traffic Penalty)
		# Spuren mit vielen Pferden in der Nähe geben Minuspunkte
		for other in get_tree().get_nodes_in_group("horses"):
			if other != self and other.lane_index == l:
				var dist = abs(other.position.x - position.x)
				if dist < 80: 
					score -= (80.0 - dist) * 0.1 

		if score > best_score:
			best_score = score
			best_lane = l
			
	# 3. Entscheidung anwenden
	if best_lane != lane_index:
		_switch_to_lane(best_lane)

func _try_switch_lane():
	var possible_lanes = []
	if lane_index > 0: possible_lanes.append(lane_index - 1)
	if lane_index < track.grid_height - 1: possible_lanes.append(lane_index + 1)
	
	if possible_lanes.size() > 0:
		_switch_to_lane(possible_lanes[randi() % possible_lanes.size()])

func _switch_to_lane(new_lane):
	if new_lane >= 0 and new_lane < track.grid_height:
		lane_index = new_lane

func _apply_visual_smoothing():
	if track:
		var target_y = float(lane_index * track.cell_size + (track.cell_size / 2.0))
		position.y = lerp(position.y, target_y, 0.1)
	
	modulate.r = lerp(modulate.r, 1.0, 0.1)
	modulate.g = lerp(modulate.g, 1.0, 0.1)
	modulate.b = lerp(modulate.b, float(target_mod_vis), 0.1) 

func _check_tiles():
	if is_shocked: return
	
	if track:
		var cell_x = int(position.x / track.cell_size)
		if cell_x >= 0 and cell_x < track.grid_width:
			var current_tile = track.grid[cell_x][lane_index]
			if current_tile == track.Tile.BOOST:
				speed_modifier = 1.5 
			elif current_tile == track.Tile.SLOW:
				speed_modifier = 0.5 
			else:
				speed_modifier = 1.0 

func _handle_repulsion(delta):
	for other in get_tree().get_nodes_in_group("horses"):
		if other == self: continue
		var diff = position - other.position
		var distance = diff.length()
		
		# WICHTIGE ÄNDERUNG: Repulsion nur anwenden, wenn sie auf der GLEICHEN Spur sind
		# und nur noch gedämpft (X-Fokus) um das "Zittern" beim Spurenwechsel zu vermeiden.
		if distance < repulsion_radius and self.lane_index == other.lane_index:
			var push_force = diff.normalized() * (repulsion_radius - distance) * (repulsion_strength * 0.3)
			position.x += push_force.x * delta

func _celebrate_win():
	track.is_race_over = true
	track.emit_signal("race_finished", horse_index, track.karma_points)

func _draw():
	var bob = sin(animation_time) * 3.0
	var leg_swing = sin(animation_time) * 6.0
	
	var draw_body_color = body_color
	var draw_head_color = head_color
	var draw_tail_color = head_color
	var draw_saddle_color = Color(1, 1, 1, 1)

	var draw_diff_color = Color(0,0, 0, 0)
	if speed_modifier > 1.2:
		draw_diff_color = Color(4, 4, 4, 0.5) 
	elif speed_modifier < 1:
		draw_diff_color = Color(4, 4, 0, 0.5) 

	draw_body_color = draw_body_color + draw_diff_color
	draw_head_color = draw_head_color + draw_diff_color
	draw_tail_color = draw_tail_color + draw_diff_color

	draw_line(Vector2(-10, -10 + bob), Vector2(-16, -4 + sin(animation_time*0.8)*7), draw_tail_color, 3.0)
	
	draw_line(Vector2(-7, -5 + bob), Vector2(-7 + leg_swing, 8), draw_body_color, 3.0)
	draw_line(Vector2(-4, -5 + bob), Vector2(-4 - leg_swing, 8), draw_body_color, 3.0)
	
	draw_rect(Rect2(-12, -15 + bob, 22, 12), draw_body_color)
	draw_rect(Rect2(-4, -15 + bob, 8, 4), draw_saddle_color) 
	
	var default_font = ThemeDB.get_fallback_font()
	var font_size = 10 
	var saddle_pos = Vector2(-5, -16 + bob)
	var saddle_size = Vector2(10, 10)
	draw_rect(Rect2(saddle_pos, saddle_size), draw_saddle_color)
	draw_string(default_font, saddle_pos + Vector2(0, 8), str(horse_index + 1), HORIZONTAL_ALIGNMENT_CENTER, saddle_size.x, font_size, Color(0, 0, 0))
	
	draw_line(Vector2(5, -5 + bob), Vector2(5 + leg_swing, 8), draw_body_color, 3.0)
	draw_line(Vector2(8, -5 + bob), Vector2(8 - leg_swing, 8), draw_body_color, 3.0)
	
	draw_line(Vector2(10, -10 + bob), Vector2(15, -20 + bob), draw_body_color, 5.0) 
	draw_rect(Rect2(13, -24 + bob, 10, 7), draw_head_color) 
	draw_rect(Rect2(14, -26 + bob, 2, 3), draw_head_color) 

	# Das ausgewählte Pferd markieren
	if track and track.selected_horse_index == horse_index:
		var wobble = sin(animation_time * 1.0) * 5.0
		var top_y = -30.0 + wobble 
		var p1 = Vector2(-8, top_y)          
		var p2 = Vector2(8, top_y)           
		var p3 = Vector2(0, top_y + 10.0)     
		var triangle_points = PackedVector2Array([p1, p2, p3])
		draw_colored_polygon(triangle_points, Color(0, 4, 0))
		draw_polyline(PackedVector2Array([p1, p2, p3, p1]), Color(1, 1, 1), 2.0)

	# Blitz-Zeichnen
	if is_shocked:
		if randf() > 0.8:
			var zap_color = Color(3, 3, 0, 0.6) 
			var points = PackedVector2Array()
			var current_y = -500.0 
			var segments = 6
			points.append(Vector2(randf_range(-50, 50), current_y))
			for i in range(1, segments):
				var progress = float(i) / segments
				var x_offset = randf_range(-40, 40)
				points.append(Vector2(x_offset, current_y * (1.0 - progress)))
			points.append(Vector2(0, 0)) 
			draw_polyline(points, zap_color, 3.0) 
			draw_polyline(points, Color(2, 2, 10), 1.0) 

	# Windlinien zeichnen
	if slipstream_bonus > 20.0 and not has_finished:
		var line_color = Color(1, 1, 5, 0.5) 
		var line_width = 1.5
		for i in range(3):
			var time_off = animation_time * 15.0 + (i * 2.1)
			var start_x = -15.0 - (fmod(time_off, 40.0))
			var line_y = -10.0 + (i * 8.0) + sin(time_off) * 2.0
			var line_len = 25.0 + (slipstream_bonus * 0.2)
			var p1 = Vector2(start_x, line_y)
			var p2 = Vector2(start_x - line_len, line_y)
			draw_polyline(PackedVector2Array([p1, p2]), line_color, line_width)
			draw_polyline(PackedVector2Array([p1, p2]), Color(2, 2, 10, 0.3), 0.5)
